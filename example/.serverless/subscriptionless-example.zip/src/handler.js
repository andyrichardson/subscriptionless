"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.snsHandler = exports.wsHandler = void 0;
var schema_1 = require("@graphql-tools/schema");
var subscriptionless_1 = require("subscriptionless");
var aws_sdk_1 = require("aws-sdk");
var schema_2 = require("./schema");
var schema = schema_1.makeExecutableSchema({
    typeDefs: schema_2.typeDefs,
    resolvers: subscriptionless_1.prepareResolvers(schema_2.resolvers),
});
var subscriptionless = subscriptionless_1.createServer({
    dynamodb: new aws_sdk_1.DynamoDB({
        logger: console,
    }),
    schema: schema,
    tableNames: {
        connections: process.env.CONNECTIONS_TABLE,
        subscriptions: process.env.SUBSCRIPTIONS_TABLE,
    },
    onSubscribe: function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        console.log("SUBSCRIBE");
        console.log(JSON.stringify(args, null, 2));
    },
    onConnect: function () { return console.log("CONNECT"); },
    onConnectionInit: function () {
        console.log("CONNECTION INIT");
        return {};
    },
    onError: console.log,
});
exports.wsHandler = subscriptionless.handler;
var snsHandler = function (event) {
    console.log(JSON.stringify(event, null, 2));
    Promise.all(event.Records.map(function (r) {
        return subscriptionless.publish({
            topic: r.Sns.TopicArn.substring(r.Sns.TopicArn.lastIndexOf(":") + 1),
            payload: JSON.parse(r.Sns.Message),
        });
    }));
};
exports.snsHandler = snsHandler;
//# sourceMappingURL=handler.js.map