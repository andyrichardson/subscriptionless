"use strict";
var __makeTemplateObject = (this && this.__makeTemplateObject) || function (cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolvers = exports.typeDefs = void 0;
var subscriptionless_1 = require("subscriptionless");
var graphql_tag_1 = require("graphql-tag");
exports.typeDefs = graphql_tag_1.default(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n  type Article {\n    id: ID!\n    title: String!\n    content: String!\n  }\n\n  type Query {\n    articles: [Article!]!\n  }\n\n  type Mutation {\n    publishArticle(title: String!, content: String!): Article!\n  }\n\n  type Subscription {\n    newArticles: [Article!]!\n  }\n"], ["\n  type Article {\n    id: ID!\n    title: String!\n    content: String!\n  }\n\n  type Query {\n    articles: [Article!]!\n  }\n\n  type Mutation {\n    publishArticle(title: String!, content: String!): Article!\n  }\n\n  type Subscription {\n    newArticles: [Article!]!\n  }\n"])));
exports.resolvers = {
    Query: {
        articles: function () { return []; }
    },
    Mutation: {
        publishArticle: function () { return ({}); }
    },
    Subscription: {
        newArticles: {
            resolve: function (event, args) { return [event.payload]; },
            subscribe: subscriptionless_1.subscribe('NEW_ARTICLE'),
            onStart: function () { return console.log("START!"); },
            onStop: function () { return console.log("STOP!"); },
        }
    }
};
var templateObject_1;
//# sourceMappingURL=schema.js.map